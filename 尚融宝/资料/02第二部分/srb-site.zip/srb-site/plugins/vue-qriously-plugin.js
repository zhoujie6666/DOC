import Vue from 'vue'
import VueQriously from 'vue-qriously'
Vue.use(VueQriously)
